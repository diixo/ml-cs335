from cs335.pprint import pprint

pdf_file= 'hw1-code.pdf'
source_files = ['gd.py', 'gradient-descent.ipynb', 'linear-regression.ipynb']

pprint(pdf_file, source_files)
